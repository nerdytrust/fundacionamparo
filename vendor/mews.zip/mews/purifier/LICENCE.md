Copyright (c) 2013 Muharrem ERİN (me@mewebstudio.com)

http://www.gnu.org/licenses/lgpl-2.1.html GNU Lesser General Public License, version 2.1